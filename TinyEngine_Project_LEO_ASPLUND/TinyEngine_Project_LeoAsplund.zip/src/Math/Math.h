#pragma once

namespace Math
{
	constexpr float TAU = 6.2831f;
}
