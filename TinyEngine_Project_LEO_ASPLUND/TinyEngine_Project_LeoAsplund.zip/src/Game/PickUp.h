#pragma once
#include "Actor.h"

class PickUp : public Actor
{
public:
	PickUp(Vector position);
};
